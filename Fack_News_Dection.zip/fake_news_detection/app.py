from flask import Flask, request, jsonify, render_template
import re

app = Flask(__name__)

FAKE_KEYWORDS = [
    "shocking", "you won't believe", "miracle", "secret", "they don't want you to know",
    "breaking", "exclusive", "hoax", "conspiracy", "fake", "fraud", "scam",
    "100% proven", "doctors hate", "click here", "share now", "urgent", "alert",
    "unbelievable", "exposed", "banned", "censored", "deep state", "illuminati"
]

def detect_fake_news(text):
    text_lower = text.lower()
    found = [kw for kw in FAKE_KEYWORDS if kw in text_lower]
    score = min(len(found) * 20, 100)
    if score >= 60:
        label = "FAKE"
        color = "red"
    elif score >= 30:
        label = "SUSPICIOUS"
        color = "orange"
    else:
        label = "LIKELY REAL"
        color = "green"
    return {"label": label, "score": score, "keywords": found, "color": color}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/detect", methods=["POST"])
def detect():
    data = request.json
    result = detect_fake_news(data.get("text", ""))
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
